# Copyright (c) 2017-2019 Uber Technologies, Inc.
# SPDX-License-Identifier: Apache-2.0

from pyro.contrib.bnn.hidden_layer import HiddenLayer

__all__ = [
    "HiddenLayer",
]
