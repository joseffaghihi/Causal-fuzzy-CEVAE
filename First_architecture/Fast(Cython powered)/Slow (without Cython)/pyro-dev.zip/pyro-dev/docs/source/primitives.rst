Primitives
==========

.. automodule:: pyro.primitives
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource


.. autofunction:: pyro.ops.jit.trace
